<ins class="adsbygoogle"
     style="display:block"
     data-ad-format="fluid"
     data-ad-layout-key="-fb+5w+4e-db+86"
     data-ad-client="ca-pub-5523280961932488"
     data-ad-slot="1638442814">
</ins>

     (adsbygoogle = window.adsbygoogle || []).push({});

  <ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-5523280961932488"
     data-ad-slot="1789651904"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>

     (adsbygoogle = window.adsbygoogle || []).push({});
